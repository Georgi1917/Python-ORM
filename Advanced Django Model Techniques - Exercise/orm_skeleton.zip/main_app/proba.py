s = "PeshoZvqra"

print(s[4:])